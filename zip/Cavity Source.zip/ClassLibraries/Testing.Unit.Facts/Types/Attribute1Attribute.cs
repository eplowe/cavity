﻿namespace Cavity.Types
{
    using System;

    [AttributeUsage(AttributeTargets.All)]
    public sealed class Attribute1Attribute : Attribute
    {
    }
}