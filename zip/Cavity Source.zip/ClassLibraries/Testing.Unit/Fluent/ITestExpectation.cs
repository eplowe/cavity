﻿namespace Cavity.Fluent
{
    public interface ITestExpectation
    {
        bool Check();
    }
}