﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.Repository.Facts.dll")]
[assembly: AssemblyTitle("Cavity.Repository.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : Repository Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : Repository Facts Library (Release)")]

#endif