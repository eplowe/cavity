﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.MSBuild.Domain.Facts.dll")]
[assembly: AssemblyTitle("Cavity.MSBuild.Domain.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : Domain MSBuild Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : Domain MSBuild Facts Library (Release)")]

#endif