﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.Repository.FileSystem.Xml.Facts.dll")]
[assembly: AssemblyTitle("Cavity.Repository.FileSystem.Xml.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : XML File System Repository Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : XML File System Repository Facts Library (Release)")]

#endif