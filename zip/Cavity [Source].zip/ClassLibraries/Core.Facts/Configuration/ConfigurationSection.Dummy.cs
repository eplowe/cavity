﻿namespace Cavity.Configuration
{
    using System.Configuration;

    public sealed class DummyConfigurationSection : ConfigurationSection
    {
    }
}