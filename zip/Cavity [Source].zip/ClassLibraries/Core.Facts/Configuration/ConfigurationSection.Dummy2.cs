﻿namespace Cavity.Configuration
{
    using System.Configuration;

    public sealed class Dummy2ConfigurationSection : ConfigurationSection
    {
    }
}