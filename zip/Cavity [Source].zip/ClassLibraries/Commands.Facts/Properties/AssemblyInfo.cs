﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.Commands.Facts.dll")]
[assembly: AssemblyTitle("Cavity.Commands.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : Commands Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : Commands Facts Library (Release)")]

#endif