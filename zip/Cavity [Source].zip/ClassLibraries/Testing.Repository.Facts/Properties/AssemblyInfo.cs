﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.Testing.Repository.Facts.dll")]
[assembly: AssemblyTitle("Cavity.Testing.Repository.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : Repository Testing Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : Repository Testing Facts Library (Release)")]

#endif