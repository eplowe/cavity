﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.ServiceLocation.Autofac.dll")]
[assembly: AssemblyTitle("Cavity.ServiceLocation.Autofac.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : Autofac Service Location Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : Autofac Service Location Library (Release)")]

#endif