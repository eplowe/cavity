﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.ServiceLocation.Facts.dll")]
[assembly: AssemblyTitle("Cavity.ServiceLocation.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : Service Location Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : Service Location Facts Library (Release)")]

#endif