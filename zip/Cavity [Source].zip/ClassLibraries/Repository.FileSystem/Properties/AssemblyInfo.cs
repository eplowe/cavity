﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.Data.FileSystem.dll")]
[assembly: AssemblyTitle("Cavity.Data.FileSystem.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : File System Data Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : File System Data Library (Release)")]

#endif