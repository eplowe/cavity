﻿namespace Cavity.Models
{
    public class Region : AddressLine
    {
    }
}