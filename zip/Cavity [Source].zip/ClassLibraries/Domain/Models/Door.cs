﻿namespace Cavity.Models
{
    public class Door : DeliveryPoint
    {
    }
}