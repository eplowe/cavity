﻿namespace Cavity.Models
{
    public class Building : DeliveryPoint
    {
    }
}