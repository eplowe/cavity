﻿namespace Cavity.Types
{
    using System;

    [AttributeUsage(AttributeTargets.All)]
    public sealed class Attribute2Attribute : Attribute
    {
    }
}