﻿namespace Cavity.Types
{
    using System.Xml.Serialization;

    [XmlRoot("root")]
    public sealed class XmlRootClass1
    {
    }
}