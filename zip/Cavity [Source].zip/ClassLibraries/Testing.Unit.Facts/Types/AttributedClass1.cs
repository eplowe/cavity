﻿namespace Cavity.Types
{
    [Attribute1Attribute]
    public sealed class AttributedClass1
    {
        [Attribute2Attribute]
        public string Value { get; set; }
    }
}