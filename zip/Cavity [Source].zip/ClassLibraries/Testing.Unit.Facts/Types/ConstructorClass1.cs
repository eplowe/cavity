﻿namespace Cavity.Types
{
    public sealed class ConstructorClass1
    {
        public ConstructorClass1(string value)
        {
            Value = value;
        }

        public string Value { get; set; }
    }
}