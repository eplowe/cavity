﻿namespace Cavity.Types
{
    public abstract class AbstractBaseClass1
    {
        public abstract bool AutoAbstract { get; set; }
    }
}