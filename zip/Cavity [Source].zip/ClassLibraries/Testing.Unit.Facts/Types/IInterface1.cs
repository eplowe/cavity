﻿namespace Cavity.Types
{
    public interface IInterface1
    {
        void Method1();
    }
}