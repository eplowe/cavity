﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;

[assembly: CLSCompliant(false)]
[assembly: AssemblyDefaultAlias("Trove.$safeprojectname$.dll")]
[assembly: AssemblyTitle("Trove.$safeprojectname$.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Trove : $safeprojectname$ Library (Debug)")]

#else

[assembly: AssemblyDescription("Trove : $safeprojectname$ Library (Release)")]

#endif

[assembly: SuppressMessage("Microsoft.Design", "CA1020:AvoidNamespacesWithFewTypes", Scope = "namespace", Target = "Trove")]