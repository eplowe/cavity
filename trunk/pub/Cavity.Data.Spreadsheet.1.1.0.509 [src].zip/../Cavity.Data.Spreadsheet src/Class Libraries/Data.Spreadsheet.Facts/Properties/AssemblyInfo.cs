﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.Data.Spreadsheet.Facts.dll")]
[assembly: AssemblyTitle("Cavity.Data.Spreadsheet.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : Data Spreadsheet Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : Data Spreadsheet Facts Library (Release)")]

#endif