﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.ServiceLocation.Unity.Facts.dll")]
[assembly: AssemblyTitle("Cavity.ServiceLocation.Unity.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : Unity Service Location Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : Unity Service Location Facts Library (Release)")]

#endif