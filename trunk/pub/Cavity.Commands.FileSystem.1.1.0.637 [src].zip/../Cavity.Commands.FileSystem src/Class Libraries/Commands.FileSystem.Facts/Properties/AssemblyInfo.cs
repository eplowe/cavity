﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.Commands.FileSystem.Facts.dll")]
[assembly: AssemblyTitle("Cavity.Commands.FileSystem.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : File System Commands Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : File System Commands Facts Library (Release)")]

#endif