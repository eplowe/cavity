﻿namespace Cavity.Threading
{
    public sealed class DerivedThreadedObject : ThreadedObject
    {
        protected override void OnDispose()
        {
        }
    }
}