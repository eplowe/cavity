﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.Transactions.Commands.Facts.dll")]
[assembly: AssemblyTitle("Cavity.Transactions.Commands.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : Commands Transactions Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : Commands Transactions Facts Library (Release)")]

#endif