﻿namespace Cavity.Net
{
    public sealed class NoContentResponse
    {
    }
}