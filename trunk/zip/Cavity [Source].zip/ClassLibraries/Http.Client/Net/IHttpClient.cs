﻿namespace Cavity.Net
{
    public interface IHttpClient
    {
        string UserAgent { get; }
    }
}