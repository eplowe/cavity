﻿namespace Cavity.Net
{
    public interface IUserAgent
    {
        string Value { get; }
    }
}