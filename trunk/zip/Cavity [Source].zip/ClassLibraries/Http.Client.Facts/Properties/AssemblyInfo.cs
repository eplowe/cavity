﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.Http.Client.Facts.dll")]
[assembly: AssemblyTitle("Cavity.Http.Client.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : HTTP Client Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : HTTP Client Facts Library (Release)")]

#endif