﻿namespace Cavity.Net
{
    public sealed class DerivedHttpMessage : HttpMessage
    {
    }
}