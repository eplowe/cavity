﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.ServiceLocation.StructureMap.Facts.dll")]
[assembly: AssemblyTitle("Cavity.ServiceLocation.StructureMap.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : StructureMap Service Location Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : StructureMap Service Location Facts Library (Release)")]

#endif