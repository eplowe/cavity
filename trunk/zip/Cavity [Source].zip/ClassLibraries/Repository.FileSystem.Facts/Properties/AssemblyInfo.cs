﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.Data.FileSystem.Facts.dll")]
[assembly: AssemblyTitle("Cavity.Data.FileSystem.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : File System Data Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : File System Data Facts Library (Release)")]

#endif