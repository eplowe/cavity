﻿namespace Cavity.Configuration
{
    public interface ISetLocatorProvider
    {
        void Configure();
    }
}