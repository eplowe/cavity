﻿namespace Cavity.Collections.Generic
{
    public sealed class DerivedLevenshteinComparer : LevenshteinComparer
    {
    }
}