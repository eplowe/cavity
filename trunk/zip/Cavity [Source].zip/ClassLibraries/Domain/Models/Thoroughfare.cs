﻿namespace Cavity.Models
{
    public class Thoroughfare : AddressLine
    {
        public string Qualifier { get; set; }
    }
}