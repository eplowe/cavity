﻿namespace Cavity.Models
{
    public class Locality : AddressLine
    {
    }
}