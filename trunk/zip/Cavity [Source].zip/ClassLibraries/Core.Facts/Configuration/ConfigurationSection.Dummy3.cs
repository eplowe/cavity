﻿namespace Cavity.Configuration
{
    using System.Configuration;

    public sealed class Dummy3ConfigurationSection : ConfigurationSection
    {
    }
}