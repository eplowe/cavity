﻿namespace Cavity.Types
{
    public static class StaticClass1
    {
    }
}