﻿namespace Cavity.Types
{
    public class Class1
    {
    }
}