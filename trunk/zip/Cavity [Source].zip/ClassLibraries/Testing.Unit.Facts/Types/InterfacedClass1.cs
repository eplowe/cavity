﻿namespace Cavity.Types
{
    using System;

    public sealed class InterfacedClass1 : IInterface1
    {
        public void Method1()
        {
            throw new NotImplementedException();
        }
    }
}