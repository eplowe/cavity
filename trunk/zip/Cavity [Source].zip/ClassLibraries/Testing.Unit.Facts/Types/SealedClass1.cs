﻿namespace Cavity.Types
{
    public sealed class SealedClass1
    {
    }
}