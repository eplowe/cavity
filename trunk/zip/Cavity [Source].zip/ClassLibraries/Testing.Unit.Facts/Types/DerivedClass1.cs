﻿namespace Cavity.Types
{
    public sealed class DerivedClass1 : Class1
    {
    }
}