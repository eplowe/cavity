﻿namespace Example
{
    public interface ITest
    {
        bool Test(string actual);
    }
}