﻿namespace Cavity.Data
{
    public interface IEntity
    {
        string ToEntity();
    }
}