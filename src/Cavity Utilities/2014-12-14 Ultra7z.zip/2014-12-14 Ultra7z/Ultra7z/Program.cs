﻿namespace Cavity
{
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Threading;

    public static class Program
    {
        private static readonly object _lock = new object();

        public static void Main(string[] args)
        {
            var files = args.Select(arg => new FileInfo(arg));
            foreach (var file in files)
            {
                Compress(file);
            }

            Thread.Sleep(10 * 1000);
        }

        private static void Compress(FileSystemInfo file)
        {
            var zip = new FileInfo(string.Format(CultureInfo.InvariantCulture, "{0}.7z", file.FullName));
            Compress(file, zip, "7z");
        }

        private static void Compress(FileSystemInfo file,
                                     FileSystemInfo zip,
                                     string format)
        {
            if (null == file)
            {
                throw new ArgumentNullException("file");
            }

            if (null == zip)
            {
                throw new ArgumentNullException("zip");
            }

            lock (_lock)
            {
                file.Refresh();
                if (!file.Exists)
                {
                    WriteError("{0} was not found", file.FullName);
                    return;
                }

                if (".7z" == file.Extension)
                {
                    WriteError("{0} is already compressed", file.FullName);
                    return;
                }

                zip.Refresh();
                if (zip.Exists)
                {
                    WriteError("{0} already exists", zip.FullName);
                    return;
                }
            }

            var process = Process.Start(new ProcessStartInfo("7z.exe")
                                            {
                                                Arguments = string.Format(CultureInfo.InvariantCulture, "a -t{0} -mx9 \"{1}\" \"{2}\"", format, zip.FullName, file.FullName),
                                            });
            if (null != process)
            {
                process.WaitForExit();
            }

            File.SetCreationTimeUtc(zip.FullName, file.CreationTimeUtc);
            File.SetLastAccessTimeUtc(zip.FullName, file.LastAccessTimeUtc);
            File.SetLastWriteTimeUtc(zip.FullName, file.LastWriteTimeUtc);
            Console.WriteLine(file.FullName);
        }

        private static void WriteError(string format, params object[] args)
        {
            var color = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(format, args);
            Console.ForegroundColor = color;
        }
    }
}