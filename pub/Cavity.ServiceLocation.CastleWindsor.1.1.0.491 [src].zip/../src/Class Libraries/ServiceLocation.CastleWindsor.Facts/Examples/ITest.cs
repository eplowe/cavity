﻿namespace Cavity.Examples
{
    public interface ITest
    {
        bool Test(string actual);
    }
}