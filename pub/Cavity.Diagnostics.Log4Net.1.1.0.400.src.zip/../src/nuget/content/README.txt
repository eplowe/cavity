﻿Please add:

	log4net.Config.XmlConfigurator.Configure();
	
to either your Main() or in your Global.asax