﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.Data.Csv.Facts.dll")]
[assembly: AssemblyTitle("Cavity.Data.Csv.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : CSV Data Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : CSV Data Facts Library (Release)")]

#endif