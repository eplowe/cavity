﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.Data.Ace.Facts.dll")]
[assembly: AssemblyTitle("Cavity.Data.Ace.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : ACE Data Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : ACE Data Facts Library (Release)")]

#endif