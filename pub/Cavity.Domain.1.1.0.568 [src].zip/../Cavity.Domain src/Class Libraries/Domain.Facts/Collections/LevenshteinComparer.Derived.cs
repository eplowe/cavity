﻿namespace Cavity.Collections
{
    public sealed class DerivedLevenshteinComparer : LevenshteinComparer
    {
    }
}