﻿namespace Cavity.Configuration
{
    public sealed class DerivedPathConfigurationSection : PathConfigurationSection
    {
    }
}