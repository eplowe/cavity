﻿namespace Cavity
{
    public sealed class DerivedDisposableObject : DisposableObject
    {
        protected override void OnDispose()
        {
        }
    }
}