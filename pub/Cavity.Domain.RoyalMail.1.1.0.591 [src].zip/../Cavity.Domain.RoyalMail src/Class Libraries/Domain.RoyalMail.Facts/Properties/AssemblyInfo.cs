﻿using System;
using System.Reflection;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDefaultAlias("Cavity.Domain.RoyalMail.Facts.dll")]
[assembly: AssemblyTitle("Cavity.Domain.RoyalMail.Facts.dll")]

#if (DEBUG)

[assembly: AssemblyDescription("Cavity : Royal Mail Domain Facts Library (Debug)")]

#else

[assembly: AssemblyDescription("Cavity : Royal Mail Domain Facts Library (Release)")]

#endif