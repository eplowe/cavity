﻿namespace Cavity.Models
{
    public interface IUserCategory
    {
        char Code { get; }

        string Name { get; }
    }
}